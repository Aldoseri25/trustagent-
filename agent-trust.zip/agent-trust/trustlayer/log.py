"""Hash-chained, self-signed action log: the evidence behind an agent's reputation."""
from __future__ import annotations

from dataclasses import dataclass, field

from .crypto import Identity, sha256_hex, verify

GENESIS = "genesis"


@dataclass
class ActionLog:
    entries: list = field(default_factory=list)

    @property
    def head(self) -> str:
        return sha256_hex(self.entries[-1]) if self.entries else GENESIS

    def append(self, agent: Identity, action: str, amount: float) -> None:
        entry = {"agent": agent.did, "seq": len(self.entries), "prev": self.head,
                 "action": action, "amount": amount}
        self.entries.append({"entry": entry, "sig": agent.sign(entry)})

    def verify(self, did: str) -> bool:
        """Every entry signed by `did`, in order, each committing to the one before."""
        prev = GENESIS
        for i, item in enumerate(self.entries):
            e = item["entry"]
            if e["agent"] != did or e["seq"] != i or e["prev"] != prev or not verify(did, e, item["sig"]):
                return False
            prev = sha256_hex(item)
        return bool(self.entries)
