"""Verifier-side policy: turns cryptographic evidence into ACCEPT / REFUSE / ESCALATE."""
from __future__ import annotations

import secrets
import time
from dataclasses import dataclass
from enum import Enum

from .credentials import Credential, RevocationList
from .crypto import Identity, verify
from .log import ActionLog


class Outcome(str, Enum):
    ACCEPT = "ACCEPT"
    REFUSE = "REFUSE"
    ESCALATE = "ESCALATE"


@dataclass(frozen=True)
class Check:
    name: str
    passed: bool
    detail: str


@dataclass(frozen=True)
class Decision:
    outcome: Outcome
    checks: tuple
    reason: str

    def failed(self) -> str | None:
        return next((c.name for c in self.checks if not c.passed), None)

    def render(self) -> str:
        lines = [f"  {'✓' if c.passed else '✗'} {c.name:<22} {c.detail}" for c in self.checks]
        return "\n".join(lines + [f"  => {self.outcome.value}: {self.reason}"])


@dataclass(frozen=True)
class Presentation:
    """What a counterparty shows: a credential, its history, and a signed answer to our challenge."""

    credential: Credential
    log: ActionLog
    response: str

    @classmethod
    def create(cls, signer: Identity, credential: Credential, log: ActionLog, challenge: dict):
        return cls(credential, log, signer.sign(challenge))


@dataclass
class Policy:
    """Atlas's rules for paying a counterparty."""

    me: Identity
    trust_anchors: frozenset
    principal: str                 # the human whose delegation bounds our authority
    delegation: Credential
    revocations: RevocationList
    required_type: str = "VerifiedVendor"

    def challenge(self) -> dict:
        return {"nonce": secrets.token_hex(16), "aud": self.me.did}

    def evaluate(self, p: Presentation, challenge: dict, amount: float, now: float | None = None) -> Decision:
        now = time.time() if now is None else now
        c, checks = p.credential, []

        def step(name: str, ok: bool, detail: str) -> bool:
            checks.append(Check(name, ok, detail))
            return ok

        def stop(outcome: Outcome, reason: str) -> Decision:
            return Decision(outcome, tuple(checks), reason)

        if not step("key possession", verify(c.subject, challenge, p.response),
                    "fresh nonce signed by the credential subject's key"):
            return stop(Outcome.REFUSE, "Presenter does not hold the key named in the credential.")
        if not step("credential signature", c.signature_valid(), "issuer signature over exact contents"):
            return stop(Outcome.REFUSE, "Credential was altered after signing.")
        if not step("trusted issuer", c.issuer in self.trust_anchors, "issuer is one of our trust anchors"):
            return stop(Outcome.REFUSE, "Issuer is not trusted by this verifier.")
        if not step("type and expiry", c.type == self.required_type and not c.expired(now),
                    f"{self.required_type}, not expired"):
            return stop(Outcome.REFUSE, "Wrong credential type or expired.")
        rl_ok = self.revocations.signature_valid() and self.revocations.issuer == c.issuer
        if not step("revocation", rl_ok and not self.revocations.covers(c.id),
                    "issuer-signed revocation list (fail closed)"):
            return stop(Outcome.REFUSE, "Credential revoked, or revocation status unverifiable.")
        if not step("action history", p.log.verify(c.subject),
                    f"{len(p.log.entries)} signed, hash-chained receipts"):
            return stop(Outcome.REFUSE, "No verifiable track record.")

        d = self.delegation
        cap = d.claim.get("maxAmount", 0)
        authorised = (d.signature_valid() and d.issuer == self.principal and d.subject == self.me.did
                      and not d.expired(now) and amount <= cap)
        if not step("own authority", authorised, f"human delegation cap {cap}, requested {amount}"):
            return stop(Outcome.ESCALATE, "Counterparty is trusted but the amount exceeds delegated authority.")
        return stop(Outcome.ACCEPT, "All checks passed; paying within delegated authority.")
