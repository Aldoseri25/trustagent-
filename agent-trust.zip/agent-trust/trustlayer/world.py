"""A small simulated world used by the demo and the tests."""
from __future__ import annotations

from dataclasses import dataclass

from .credentials import Credential, RevocationList, issue
from .crypto import Identity
from .log import ActionLog
from .policy import Decision, Policy, Presentation


@dataclass
class World:
    registry: Identity
    human: Identity
    atlas: Identity
    meridian: Identity
    mallory: Identity
    vendor_cred: Credential
    log: ActionLog
    policy: Policy

    def request(self, signer: Identity, cred: Credential, log: ActionLog, amount: float, now=None) -> Decision:
        """Run one full interaction: challenge, presentation, verification."""
        ch = self.policy.challenge()
        return self.policy.evaluate(Presentation.create(signer, cred, log, ch), ch, amount, now)

    def revoke_vendor(self) -> None:
        self.policy.revocations = RevocationList.create(self.registry, [self.vendor_cred.id])


def build_world(cap: float = 500) -> World:
    registry, human, atlas, meridian, mallory = (
        Identity.generate(n) for n in ("Registry", "Human", "Atlas", "Meridian", "Mallory"))
    vendor_cred = issue(registry, meridian.did, "VerifiedVendor", {"category": "office-supplies"})
    log = ActionLog()
    for action, amount in (("delivered PO-114", 80), ("delivered PO-131", 210), ("delivered PO-152", 45)):
        log.append(meridian, action, amount)
    delegation = issue(human, atlas.did, "Delegation", {"scope": "pay-invoice", "maxAmount": cap})
    policy = Policy(atlas, frozenset({registry.did}), human.did, delegation, RevocationList.create(registry))
    return World(registry, human, atlas, meridian, mallory, vendor_cred, log, policy)
