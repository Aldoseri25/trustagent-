"""Identity and signing primitives: Ed25519 keys, did:key identifiers, canonical JSON."""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
from dataclasses import dataclass

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_ED25519_MULTICODEC = b"\xed\x01"
_DID_PREFIX = "did:key:z"


def canonical(obj) -> bytes:
    """Deterministic JSON so signer and verifier hash identical bytes."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def sha256_hex(obj) -> str:
    return hashlib.sha256(canonical(obj)).hexdigest()


def _b58encode(data: bytes) -> str:
    n, out = int.from_bytes(data, "big"), ""
    while n:
        n, r = divmod(n, 58)
        out = _ALPHABET[r] + out
    return "1" * (len(data) - len(data.lstrip(b"\0"))) + out


def _b58decode(text: str) -> bytes:
    n = 0
    for ch in text:
        n = n * 58 + _ALPHABET.index(ch)
    body = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return b"\0" * (len(text) - len(text.lstrip("1"))) + body


def did_to_public_key(did: str) -> Ed25519PublicKey:
    """Resolve a did:key straight to its public key. No registry or network needed."""
    if not did.startswith(_DID_PREFIX):
        raise ValueError("unsupported DID method")
    raw = _b58decode(did[len(_DID_PREFIX):])
    if not raw.startswith(_ED25519_MULTICODEC) or len(raw) != 34:
        raise ValueError("not an Ed25519 did:key")
    return Ed25519PublicKey.from_public_bytes(raw[2:])


def verify(did: str, obj, signature: str) -> bool:
    """True only if `signature` is a valid signature by `did` over `obj`."""
    try:
        did_to_public_key(did).verify(base64.b64decode(signature, validate=True), canonical(obj))
        return True
    except (InvalidSignature, ValueError, binascii.Error):
        return False


@dataclass
class Identity:
    """An agent, human or issuer: a name plus a private key. The DID is derived from the key."""

    name: str
    _key: Ed25519PrivateKey

    @classmethod
    def generate(cls, name: str) -> "Identity":
        return cls(name, Ed25519PrivateKey.generate())

    @property
    def did(self) -> str:
        raw = self._key.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        )
        return _DID_PREFIX + _b58encode(_ED25519_MULTICODEC + raw)

    def sign(self, obj) -> str:
        return base64.b64encode(self._key.sign(canonical(obj))).decode()
