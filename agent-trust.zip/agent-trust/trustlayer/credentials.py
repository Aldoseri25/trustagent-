"""Verifiable-credential-style claims and signed revocation lists."""
from __future__ import annotations

import secrets
import time
from dataclasses import asdict, dataclass

from .crypto import Identity, verify


@dataclass(frozen=True)
class Credential:
    """A signed statement: `issuer` says `claim` about `subject`."""

    id: str
    type: str
    issuer: str
    subject: str
    claim: dict
    expires: float
    proof: str

    def body(self) -> dict:
        return {k: v for k, v in asdict(self).items() if k != "proof"}

    def signature_valid(self) -> bool:
        return verify(self.issuer, self.body(), self.proof)

    def expired(self, now: float) -> bool:
        return now >= self.expires


def issue(issuer: Identity, subject: str, type: str, claim: dict, ttl: float = 365 * 86400) -> Credential:
    body = {
        "id": "urn:vc:" + secrets.token_hex(5),
        "type": type,
        "issuer": issuer.did,
        "subject": subject,
        "claim": claim,
        "expires": time.time() + ttl,
    }
    return Credential(**body, proof=issuer.sign(body))


@dataclass(frozen=True)
class RevocationList:
    """Issuer-signed list of revoked credential ids. Verifiers fail closed if it does not verify."""

    issuer: str
    revoked: tuple
    proof: str

    @classmethod
    def create(cls, issuer: Identity, revoked=()) -> "RevocationList":
        revoked = tuple(sorted(revoked))
        return cls(issuer.did, revoked, issuer.sign({"issuer": issuer.did, "revoked": list(revoked)}))

    def signature_valid(self) -> bool:
        return verify(self.issuer, {"issuer": self.issuer, "revoked": list(self.revoked)}, self.proof)

    def covers(self, credential_id: str) -> bool:
        return credential_id in self.revoked
