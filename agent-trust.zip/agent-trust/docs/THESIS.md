# Two-year thesis: agent identity and reputation

By 2028 most commerce between organisations will be negotiated by software acting for people. Three things must exist or it collapses into spam and fraud: identity an agent can prove, authority that is scoped and revocable, and a record others can verify without asking the agent's owner.

**Identity** will be cryptographic and cheap. Every agent holds a key and a DID; names, logos and model brands will mean nothing. Possession of a key means everything, so every interaction opens with a challenge.

**Authority** will flow as delegation chains (human → organisation → agent → sub-agent), each hop a signed credential that can only narrow scope: amount, time, counterparty, action. Verifiers check the chain, not a profile page. Revocation must be as fast as issuance, because an agent doing 10,000 tasks a day can do 10,000 wrong things before anyone reads an email.

**Reputation** will stop being a number. A score is a rumour; signed receipts counter-signed by counterparties and anchored in hash-chained logs are evidence. Each verifier applies its own policy to the same evidence, so a payments agent and a research agent can trust one vendor differently.

The hard problems are sybils and issuers. Fresh keys are free, so new agents start with zero authority and earn it through human-backed delegations and vouches that put the voucher's own standing at stake. Trust anchors will be plural and competing, like certificate authorities, with transparency logs to expose bad issuers.

Whoever standardises the claims vocabulary, the revocation path and the policy language, built on DIDs and Verifiable Credentials, becomes the TLS of the agent economy.
