import copy
from dataclasses import replace

import pytest

from trustlayer import Outcome, issue
from trustlayer.world import build_world


@pytest.fixture
def w():
    return build_world(cap=500)


def test_honest_vendor_accepted(w):
    assert w.request(w.meridian, w.vendor_cred, w.log, 120).outcome is Outcome.ACCEPT


def test_over_cap_escalates(w):
    d = w.request(w.meridian, w.vendor_cred, w.log, 900)
    assert d.outcome is Outcome.ESCALATE and d.failed() == "own authority"


def test_spoof_fails_possession(w):
    d = w.request(w.mallory, w.vendor_cred, w.log, 120)
    assert d.outcome is Outcome.REFUSE and d.failed() == "key possession"


def test_self_issued_fails_issuer(w):
    forged = issue(w.mallory, w.mallory.did, "VerifiedVendor", {})
    assert w.request(w.mallory, forged, w.log, 120).failed() == "trusted issuer"


def test_tampered_credential_fails_signature(w):
    edited = replace(w.vendor_cred, subject=w.mallory.did)
    assert w.request(w.mallory, edited, w.log, 120).failed() == "credential signature"


def test_revocation_blocks(w):
    w.revoke_vendor()
    assert w.request(w.meridian, w.vendor_cred, w.log, 120).failed() == "revocation"


def test_forged_revocation_list_fails_closed(w):
    w.policy.revocations = replace(w.policy.revocations, issuer=w.mallory.did)
    assert w.request(w.meridian, w.vendor_cred, w.log, 120).outcome is Outcome.REFUSE


def test_rewritten_history_fails(w):
    log = copy.deepcopy(w.log)
    log.entries[0]["entry"]["amount"] = 1
    assert w.request(w.meridian, w.vendor_cred, log, 120).failed() == "action history"


def test_expired_credential_refused(w):
    d = w.request(w.meridian, w.vendor_cred, w.log, 120, now=w.vendor_cred.expires + 1)
    assert d.failed() == "type and expiry"


def test_forged_delegation_gives_no_authority(w):
    w.policy.delegation = issue(w.mallory, w.atlas.did, "Delegation", {"maxAmount": 10**6})
    assert w.request(w.meridian, w.vendor_cred, w.log, 120).outcome is Outcome.ESCALATE
