"""Run the trust-gated demo: python demo.py"""
import copy
from dataclasses import replace

from trustlayer import issue
from trustlayer.world import build_world


def main() -> None:
    w = build_world(cap=500)
    forged = issue(w.mallory, w.mallory.did, "VerifiedVendor", {"category": "office-supplies"})
    edited = replace(w.vendor_cred, subject=w.mallory.did)          # keeps Meridian's old signature
    cut_log = copy.deepcopy(w.log)
    cut_log.entries[1]["entry"]["amount"] = 1                       # rewrite history

    scenarios = [
        ("Honest vendor, 120 BHD", w.meridian, w.vendor_cred, w.log, 120),
        ("Honest vendor, 900 BHD (over cap)", w.meridian, w.vendor_cred, w.log, 900),
        ("ATTACK spoofed identity: Mallory replays Meridian's credential", w.mallory, w.vendor_cred, w.log, 120),
        ("ATTACK self-issued credential", w.mallory, forged, w.log, 120),
        ("ATTACK tampered credential", w.mallory, edited, w.log, 120),
        ("ATTACK rewritten history", w.meridian, w.vendor_cred, cut_log, 120),
    ]
    for title, signer, cred, log, amount in scenarios:
        print(f"\n{title}\n{w.request(signer, cred, log, amount).render()}")

    w.revoke_vendor()
    print("\nRegistry revokes Meridian's credential, then Meridian asks again")
    print(w.request(w.meridian, w.vendor_cred, w.log, 120).render())


if __name__ == "__main__":
    main()
