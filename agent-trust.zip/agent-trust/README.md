# TrustLayer: the agent that earns trust

A small, readable trust layer for AI agents. An agent only accepts a task after its counterparty proves **who it is**, **what it is allowed to do** and **what it has done**, and after checking that the task fits the authority its own human delegated.

**Live demo (browser, real signatures):** `https://<your-username>.github.io/<repo>/`  ·  **Thesis:** [docs/THESIS.md](docs/THESIS.md)

```bash
pip install -r requirements.txt
python demo.py        # trust-gated decisions + attacks, printed step by step
pytest -q             # 10 tests, one per defence
```

## Architecture: identity → claims → verification → policy

| Layer | Module | What it does |
|---|---|---|
| Identity | `crypto.py` | Ed25519 key per agent. The identifier is a standard `did:key`, so any verifier resolves the public key from the DID itself, with no registry. |
| Claims | `credentials.py`, `log.py` | VC-style signed credentials (`VerifiedVendor`, `Delegation`), an issuer-signed revocation list, and a hash-chained, self-signed action log used as reputation evidence. |
| Verification | `policy.py` | Challenge-response key possession, signature, issuer, expiry, revocation (fail closed), history chain. |
| Policy | `policy.py` | The verifier decides: `ACCEPT`, `REFUSE`, or `ESCALATE` to the human. Every decision lists the checks behind it. There is no score. |

**Grant / scope / revoke:** granting is issuing a signed credential; scoping is narrowing its claim (for example `maxAmount`); revoking is the issuer publishing a new signed list.

## Failure test: what a malicious agent tries

| Attack | Caught by |
|---|---|
| Replay Meridian's real credential | `key possession`: Mallory cannot sign the fresh nonce |
| Issue herself a `VerifiedVendor` credential | `trusted issuer` |
| Edit a copy of Meridian's credential | `credential signature` |
| Rewrite Meridian's history | `action history` (hash chain and signatures) |
| Use a revoked credential, or forge the revocation list | `revocation` (signed, fail closed) |
| Forge a delegation to raise Atlas's cap | `own authority` (must be signed by the principal) |

## Layout

```
trustlayer/   crypto, credentials, log, policy, world (simulation)
tests/        one test per defence
demo.py       CLI walkthrough
docs/         index.html (GitHub Pages live demo) and THESIS.md
```

## Notes

Built with Claude. Extends `did:key` and the W3C VC data model in simplified form (canonical JSON signatures, not JSON-LD or Data Integrity proofs). Out of scope: transport between agents, sybil resistance at scale, selective-disclosure credentials, key rotation. The browser demo in `docs/` uses ECDSA P-256 via WebCrypto; the Python package uses Ed25519.
